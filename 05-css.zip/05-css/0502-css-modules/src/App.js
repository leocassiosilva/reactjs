import React from 'react';
import Produto from './Components/Produto';

const App = () => {
  return (
    <div>
      <Produto />
    </div>
  );
};

export default App;
