import React from 'react';

const ProdutoCustomizado = () => {
  return (
    <div>
      <h2>Produto Customizado</h2>
    </div>
  );
};

export default ProdutoCustomizado;
