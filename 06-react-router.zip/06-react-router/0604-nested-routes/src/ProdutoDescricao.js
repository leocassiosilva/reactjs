import React from 'react';

const ProdutoDescricao = () => {
  return (
    <div>
      <h2>Produto Descrição</h2>
    </div>
  );
};

export default ProdutoDescricao;
