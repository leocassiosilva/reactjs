import React from 'react';

const NaoEncontrada = () => {
  return (
    <div>
      <p>Erro: 404 - Página não encontrada</p>
    </div>
  );
};

export default NaoEncontrada;
