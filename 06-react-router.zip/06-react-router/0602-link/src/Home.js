import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      <p>Essa é a home</p>
    </div>
  );
};

export default Home;
