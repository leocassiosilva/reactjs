import React from 'react';

const Header = () => {
  return <div>Esse é o Header</div>;
};

export default Header;
